package com.example.gameaudit

import android.app.Activity
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URI
import java.net.URL
import java.nio.charset.Charset
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var webView: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = false
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = false
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(GameBridge(), "AndroidBridge")
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
    }

    @Deprecated("Deprecated in Android API")
    override fun onBackPressed() {
        if (this::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    inner class GameBridge {
        @JavascriptInterface
        fun detect(baseUrl: String, token: String, testUserId: String, victimUserId: String,
                   allowXpTest: Boolean, xpAmount: String): String {
            return try {
                val base = validateBase(baseUrl)
                require(token.isNotBlank()) { "أدخل التوكن أولاً" }
                require(!token.contains('\n') && !token.contains('\r')) { "التوكن غير صالح" }
                require(testUserId.isNotBlank() && victimUserId.isNotBlank()) { "أدخل معرّفات الحسابات" }

                val auth = JSONObject().put("Authorization", "Bearer $token")
                val findings = JSONArray()
                val baseText = base.toString().trimEnd('/')

                // 1) IDOR: read-only request against the supplied test account.
                val idorUrl = "$baseText/api/user/${encodePathSegment(victimUserId)}"
                val idor = request(base, idorUrl, "GET", auth, null)
                if (idor.optInt("status") == 200 && isJsonObject(idor.optString("body"))) {
                    val data = JSONObject(idor.optString("body"))
                    if (data.has("id") || data.has("username") || data.has("name") || data.has("email")) {
                        findings.put(finding("IDOR", "🔴 احتمال الوصول لبيانات حساب آخر",
                            "استُخدم توكن الحساب $testUserId لقراءة مسار الحساب $victimUserId. تحقق يدوياً من ملكية الحساب والبيانات المعادة.",
                            idorUrl, "GET", auth, null, idor.optString("body").take(500)))
                    }
                }

                // 2) Admin endpoint: GET only.
                val adminUrl = "$baseText/api/admin/users"
                val admin = request(base, adminUrl, "GET", auth, null)
                if (admin.optInt("status") == 200) {
                    findings.put(finding("ADMIN", "🔴 احتمال انكشاف مسار الإدارة",
                        "أعاد مسار الإدارة HTTP 200. افحص محتوى الرد وتأكد أن حساب اللاعب لا يملك صلاحية الإدارة.",
                        adminUrl, "GET", auth, null, admin.optString("body").take(500)))
                }

                // 3) XP tampering is opt-in because it can change game data.
                if (allowXpTest) {
                    val amount = xpAmount.toIntOrNull() ?: 1
                    require(amount in 1..10) { "قيمة اختبار الخبرة يجب أن تكون بين 1 و10 لتقليل أثر الاختبار" }
                    val xpUrl = "$baseText/api/game/add-xp"
                    val xpBody = JSONObject().put("userId", testUserId).put("amount", amount).put("xp", amount)
                    val xpHeaders = JSONObject(auth.toString()).put("Content-Type", "application/json")
                    val xp = request(base, xpUrl, "POST", xpHeaders, xpBody.toString())
                    if (xp.optInt("status") == 200) {
                        findings.put(finding("TAMPER", "🟠 قبول طلب تعديل الخبرة (يحتاج تحققاً)",
                            "قبل السيرفر طلب اختبار صغير بقيمة $amount. افحص سجل الحساب للتأكد مما تغيّر؛ HTTP 200 وحده لا يثبت نجاح التلاعب.",
                            xpUrl, "POST", xpHeaders, xpBody, xp.optString("body").take(500)))
                    }
                }

                // 4) Public leaderboard endpoint.
                val leaderboardUrl = "$baseText/api/game/leaderboard"
                val leaderboard = request(base, leaderboardUrl, "GET", JSONObject(), null)
                if (leaderboard.optInt("status") == 200) {
                    findings.put(finding("NOAUTH", "🟠 مسار يعيد بيانات دون مصادقة",
                        "أعاد مسار لوحة الترتيب HTTP 200 دون توكن. قد يكون هذا مقصوداً إذا كانت لوحة الترتيب عامة.",
                        leaderboardUrl, "GET", JSONObject(), null, leaderboard.optString("body").take(500)))
                }

                // 5) Fake-token test.
                val fakeUrl = "$baseText/api/user/${encodePathSegment(testUserId)}"
                val fakeHeaders = JSONObject().put("Authorization", "Bearer fake_token_123")
                val fake = request(base, fakeUrl, "GET", fakeHeaders, null)
                if (fake.optInt("status") == 200) {
                    findings.put(finding("FAKE_TOKEN", "🔴 احتمال قبول توكن غير صالح",
                        "أعاد مسار المستخدم HTTP 200 عند استخدام توكن تجريبي غير صالح. تحقق من محتوى الرد ومن آلية المصادقة.",
                        fakeUrl, "GET", fakeHeaders, null, fake.optString("body").take(500)))
                }

                JSONObject().put("findings", findings).put("count", findings.length()).toString()
            } catch (e: Exception) {
                JSONObject().put("error", e.message ?: "حدث خطأ غير معروف").toString()
            }
        }

        @JavascriptInterface
        fun sendRequest(baseUrl: String, url: String, method: String, headersJson: String, body: String,
                        mutationConfirmed: Boolean): String {
            return try {
                val base = validateBase(baseUrl)
                val verb = method.uppercase(Locale.ROOT)
                require(verb in setOf("GET", "HEAD", "POST", "PUT", "DELETE", "OPTIONS")) {
                    "طريقة الطلب غير مدعومة"
                }
                if (verb !in setOf("GET", "HEAD", "OPTIONS")) {
                    require(mutationConfirmed) { "أكد أولاً أنك تفهم أن هذا الطلب قد يغيّر بيانات اللعبة" }
                }
                val headerObject = JSONObject(headersJson.ifBlank { "{}" })
                val response = request(base, url, verb, headerObject, body.takeIf { it.isNotBlank() && verb !in setOf("GET", "HEAD") })
                JSONObject()
                    .put("sent", JSONObject().put("method", verb).put("url", url).put("headers", headerObject).put("body", body))
                    .put("received", JSONObject().put("status", response.optInt("status")).put("body", response.optString("body")))
                    .put("exploited", response.optInt("status") == 200)
                    .put("error", response.optString("error").takeIf { it.isNotBlank() })
                    .toString()
            } catch (e: Exception) {
                JSONObject().put("error", e.message ?: "تعذر إرسال الطلب").toString()
            }
        }

        private fun validateBase(value: String): URI {
            require(value.isNotBlank()) { "أدخل رابط السيرفر" }
            val uri = URI(value.trim().trimEnd('/'))
            val scheme = uri.scheme?.lowercase(Locale.ROOT)
            require(scheme == "https" || scheme == "http") { "استخدم رابط HTTP أو HTTPS صحيحاً" }
            require(!uri.host.isNullOrBlank() && uri.userInfo == null && uri.query == null && uri.fragment == null) {
                "الرابط غير صالح؛ لا تضع بيانات دخول أو معاملات داخل الرابط الأساسي"
            }
            return uri
        }

        private fun request(base: URI, address: String, method: String, headers: JSONObject, body: String?): JSONObject {
            val target = URI(address)
            require(target.isAbsolute && target.host != null && target.userInfo == null && target.fragment == null) { "أدخل رابطاً كاملاً وصحيحاً" }
            require(sameOrigin(base, target)) { "مسموح بالاتصال بنفس السيرفر الذي أدخلته فقط" }
            require(target.scheme.equals(base.scheme, true)) { "لا يمكن تغيير بروتوكول الاتصال" }

            val connection = (URL(address).openConnection() as HttpURLConnection)
            return try {
                connection.requestMethod = method
                connection.connectTimeout = 8000
                connection.readTimeout = 8000
                connection.instanceFollowRedirects = false
                connection.setRequestProperty("User-Agent", "GameAudit-Android/1.0")
                val keys = headers.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    val value = headers.optString(key)
                    require(key.matches(Regex("[A-Za-z0-9-]{1,64}"))) { "اسم هيدر غير صالح" }
                    require(!key.equals("Host", true) && !key.equals("Content-Length", true) &&
                            !key.equals("Connection", true) && !key.equals("Transfer-Encoding", true)) {
                        "هذا الهيدر محظور لأسباب أمنية: $key"
                    }
                    require(!value.contains('\n') && !value.contains('\r')) { "قيمة هيدر غير صالحة" }
                    connection.setRequestProperty(key, value)
                }
                if (body != null && method !in setOf("GET", "HEAD")) {
                    connection.doOutput = true
                    if (connection.getRequestProperty("Content-Type") == null) {
                        connection.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    }
                    connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                }
                val status = connection.responseCode
                val stream = if (status >= 400) connection.errorStream else connection.inputStream
                val responseText = if (stream == null) "" else stream.use { readLimited(it, 5000) }
                JSONObject().put("status", status).put("body", responseText)
            } catch (e: Exception) {
                JSONObject().put("status", 0).put("body", "").put("error", e.message ?: "Network error")
            } finally {
                connection.disconnect()
            }
        }

        private fun readLimited(input: java.io.InputStream, maxBytes: Int): String {
            val output = ByteArrayOutputStream()
            val buffer = ByteArray(1024)
            var total = 0
            while (total < maxBytes) {
                val count = input.read(buffer, 0, minOf(buffer.size, maxBytes - total))
                if (count <= 0) break
                output.write(buffer, 0, count)
                total += count
            }
            return output.toByteArray().toString(Charset.forName("UTF-8"))
        }

        private fun sameOrigin(a: URI, b: URI): Boolean {
            fun port(uri: URI): Int = if (uri.port != -1) uri.port else if (uri.scheme.equals("https", true)) 443 else 80
            return a.scheme.equals(b.scheme, true) && a.host.equals(b.host, true) && port(a) == port(b)
        }

        private fun isJsonObject(value: String): Boolean = try { JSONObject(value); true } catch (_: Exception) { false }

        private fun encodePathSegment(value: String): String =
            java.net.URLEncoder.encode(value, "UTF-8").replace("+", "%20")

        private fun finding(type: String, title: String, detail: String, url: String, method: String,
                            headers: JSONObject, body: JSONObject?, response: String): JSONObject {
            return JSONObject().put("type", type).put("title", title).put("detail", detail)
                .put("url", url).put("method", method).put("headers", headers)
                .put("body", body ?: JSONObject.NULL).put("response", response)
        }
    }
}
