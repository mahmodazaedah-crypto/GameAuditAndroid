# طريقة استخراج APK

## الخيار الأسهل: GitHub Actions

1. أنشئ مستودعاً جديداً في GitHub باسم `GameAuditAndroid`.
2. فك ضغط `GameAuditAndroid-project.zip` على جهازك.
3. ارفع **محتويات** مجلد `GameAuditAndroid` إلى المستودع (يجب أن يظهر `app` وملف `settings.gradle.kts` في الصفحة الرئيسية للمستودع، وليس داخل مجلد إضافي).
4. افتح تبويب **Actions**.
5. اختر **Build Android APK** ثم **Run workflow**.
6. بعد انتهاء البناء بنجاح، افتح نتيجة التشغيل ونزّل الملف `game-audit-debug-apk` من قسم Artifacts.
7. فك ضغط ملف الـ Artifact، ثم ثبّت `app-debug.apk` على هاتف Android. قد يطلب الهاتف السماح بالتثبيت من هذا المصدر.

## ملاحظة
ملف المشروع يحتوي على إعداد البناء التلقائي، لكن ملف APK الثنائي لا يُنشأ إلا عند تشغيل Gradle مع Android SDK. بيئة إعداد المشروع الحالية لا تحتوي على Android SDK أو Gradle، لذلك لم أضع رابط APK غير مبني أو غير مختبر.
